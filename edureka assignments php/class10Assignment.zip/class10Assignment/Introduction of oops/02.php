<?php 
class example{
    public function dishplay($x){
        echo "Hello All, I am $x";
    }
}
$obj = new example();
$obj->dishplay('Scott');
?>