<?php 
class example{
    public function dishplay(){
        echo "'MyClass class has intialized !'";
    }
}
$obj = new example();
$obj->dishplay();
?>